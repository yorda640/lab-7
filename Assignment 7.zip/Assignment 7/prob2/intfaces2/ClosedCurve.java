package prob2.intfaces2;

public interface ClosedCurve {
	public double computePerimeter();
}
